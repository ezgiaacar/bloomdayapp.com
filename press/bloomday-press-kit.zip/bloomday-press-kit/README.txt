BloomDay Press Kit
==================

Thank you for your interest in BloomDay!

CONTENTS
--------

/logos/
  logo-dark-bg.png      — Full logo on dark background (1200x400)
  logo-light-bg.png     — Full logo on light background (1200x400)
  logo-transparent.png  — Full logo on transparent background (1200x400)
  icon-dark.png         — App icon on dark background (512x512)
  icon-light.png        — App icon on light background (512x512)

/scenes/
  scene1-interior.png   — Cozy Interior garden theme preview
  scene2-garden.png     — English Garden theme preview
  scene3-allotment.png  — Countryside Allotment theme preview

/plants/
  plant-collection-showcase.png — Grid showcase of selected plant species

brand-guidelines.png    — Color palette, typography, and usage guidelines

QUICK FACTS
-----------
App Name:       BloomDay
Tagline:        Plan your day. Grow your garden.
Category:       Productivity / Lifestyle
Platforms:      iOS & Android
Price:          Free (Premium optional)
Plant Species:  131
Garden Themes:  3
Founder:        Ezgi Acar
Team Size:      1 (solo developer)
Website:        bloomdayapp.com
Press Page:     bloomdayapp.com/press
Contact:        bloomday.app@icloud.com

BRAND COLORS
------------
Dark:           #111810
Warm Dark:      #2a2520
Sage:           #5e7054
Green (Primary):#9ab06a
Cream:          #f5f0e8

TYPOGRAPHY
----------
Headings:       Playfair Display (Google Fonts)
Body:           DM Sans (Google Fonts)

USAGE GUIDELINES
----------------
- All assets are free to use for editorial and press purposes
- Please credit "BloomDay" and link to bloomdayapp.com where possible
- Do not alter logo colors or proportions
- For additional assets or high-res versions, email bloomday.app@icloud.com

